﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        drop_Products.Attributes.Add("OnClick", "javascript:document.getElementById('txt_price').value=this.value;");
        if (Request.QueryString["au"] != "" && Request.QueryString["au"] != null)
        {
            ZarrinPal.WebServices zp = new ZarrinPal.WebServices();
            string au = Request.QueryString["au"].ToString();
            int a = zp.PaymentVerification("4dac9b8c-9dac-47d6-8745-14feae8e8897", au, int.Parse(Request.QueryString["price"].ToString()));
            if (a == 1)
            {
                lbl_result.Text = "شماره سند : " + Request.QueryString["refID"].ToString() + "<br><br> رسید دیجیتالی : " + Request.QueryString["au"].ToString() + "<br><br>" + "پرداخت با موفقیت انجام شد";
            }
            if (a == -1)
            {
                lbl_result.Style.Add(HtmlTextWriterStyle.Color, "Red");
                lbl_result.Text = "اطلاعات ناقص میباشد";
            }
            if (a == -2)
            {
                lbl_result.Text = "درگاه پرداخت دچار مشکل شده است";
            }
            if (a == 0)
            {
                lbl_result.Text = "عملیات با مشکل مواجه شده است";
            }
        }
    }
    protected void btn_Pay_Click(object sender, EventArgs e)
    {
        System.Net.ServicePointManager.Expect100Continue = false;
        ZarrinPal.WebServices zp = new ZarrinPal.WebServices();
        string au = zp.PaymentRequest("4dac9b8c-9dac-47d6-8745-14feae8e8897", int.Parse(txt_price.Text.Replace(" تومان", "")), "http://pay.MyDomain.com/Default.aspx?price=" + txt_price.Text.Replace(" تومان", "") + "&UserID=1&FactorID=1", Server.UrlEncode(txt_dsc.Text));
        if (au.Length == 36)
        {
            Response.Redirect("http://www.zarinpal.com/users/pay_invoice/" + au);
        }
        else
        {
            lbl_result.Style.Add(HtmlTextWriterStyle.Color, "Red");
            lbl_result.Text = "اتصال با بانک برقرار نشد. دوبازه سعی نمایید";
        }
    }
}