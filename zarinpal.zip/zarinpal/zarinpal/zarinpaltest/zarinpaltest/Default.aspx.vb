﻿Partial Public Class _Default
    Inherits System.Web.UI.Page


    Protected Sub BtnOk_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnOk.Click
        System.Net.ServicePointManager.Expect100Continue = False
        Dim Zarp As New zarinpal.WebServices, Auth As String
        Auth = Zarp.PaymentRequest("your merchant id", CInt(txtAmount.Text), "http://www.sample.com", Server.UrlEncode(TxtDescription.Text))
        If Auth.Length <> 36 Then
            Response.Write("error")
        Else
            Response.Redirect("http://www.zarinpal.com/users/pay_invoice/" & Auth)
        End If
    End Sub
End Class